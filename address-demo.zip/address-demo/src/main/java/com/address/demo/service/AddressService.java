package com.address.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.address.demo.entity.Address;
import com.address.demo.repository.AddressRepository;

/**
 * 
 * @author Raneet This is a service that will defined different function that
 *         will be used to interact with the db it will be use by the Controller
 *         class
 */

@Service
public class AddressService {

	@Autowired
private  AddressRepository addressRepository;

	public AddressService() {
	}

	public AddressService(AddressRepository addressRepository) {
		this.addressRepository = addressRepository;
	}

	public List<Address> findByCountryCode(String countryCode) {
		return addressRepository.findByCountryCode(countryCode);
	}
	

}
