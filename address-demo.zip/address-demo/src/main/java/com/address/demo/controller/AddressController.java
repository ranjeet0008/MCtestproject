package com.address.demo.controller;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.address.demo.entity.Address;
import com.address.demo.service.AddressService;
import com.sun.istack.NotNull;

/**
 * @author Ranjeet
 * 
 *         This controller will receive a request with parameter and will return
 *         a list of Address from DB
 *         http://localhost:8080/address?countryCode=USA OR
 *         http://localhost:8080/address?countryCode=CN
 *
 */

@RestController
@Validated
public class AddressController {
	private static final Logger LOG = LoggerFactory.getLogger(AddressController.class);
	@Autowired
	private AddressService addressService;

	
	
	@GetMapping("/address/{countrycode}")
	public List<Address> retrieveAddressbycountrycode(@PathVariable @NotNull String countrycode) {

		LOG.info("Entering into the controller - AddressController - retrieveAddress");

		List<Address> addressList = new ArrayList<>();

		try {

			addressList = addressService.findByCountryCode(countrycode);

		} catch (Exception e) {
			LOG.info("Exception in controller - AddressController - retrieveAddress {} ", e.getMessage());
		}

		LOG.info("Returning from the controller - AddressController - retrieveAddress");

		return addressList;

	}


}
