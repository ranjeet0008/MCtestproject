/**
 * 
 */
package com.address.demo.repository;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.address.demo.entity.Address;

/**
 * @author Ranjeet Kumar
 *
 */

@RunWith(SpringRunner.class)
@DataJpaTest
class AddressRepositoryTest {
	@Autowired
	AddressRepository addressRepository;

	@Test
	public void testFindAll() {
		List<Address> addressList = addressRepository.findAll();
		assertEquals(8, addressList.size());
		assertNotNull(addressList);

	}

	@Test
	public void testFindByCountryCodelUSA() {
		List<Address> addressList = addressRepository.findByCountryCode("USA");
		assertEquals(6, addressList.size());
		assertNotNull(addressList);

	}

	@Test
	public void testFindByCountryCodelCN() {
		List<Address> addressList = addressRepository.findByCountryCode("CN");
		assertEquals(2, addressList.size());
		assertNotNull(addressList);

	}

}
